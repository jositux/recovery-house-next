"use client"

import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { format, addDays, parseISO } from "date-fns"
import { es } from "date-fns/locale"
import { CalendarIcon, Minus, Plus, Users, X } from "lucide-react"
import { useSearchParams } from "next/navigation"
import styles from "./BookingWidget.module.css"

interface BookingData {
  checkIn: string
  checkOut: string
  guests: number
  nights: number
  price: number
  cleaning: number
  discountStayType: string
  discountPercentageStayApplied: number
  discountStayAmount: number
  totalPrice: number
}

interface Booking {
  checkIn: string
  checkOut: string
  patient: string
  guests: number
  price: number
  cleaning: number
}

interface BookingWidgetProps {
  price: number
  cleaning: number
  bookings: Booking[]
  maxGuests: number
  disableDates: string
  minMediumStayRange: number
  maxMediumStayRange: number
  minLongStayRange: number
  maxLongStayRange: number
  discount_percentage_medium_stay: number
  discount_percentage_long_stay: number
  prepayment_percentage: number
  defaultCheckIn?: string
  defaultCheckOut?: string
  defaultGuests?: number
  onSubmit?: (bookingData: BookingData) => void
}

export function BookingWidget({
  price,
  cleaning,
  discount_percentage_medium_stay,
  discount_percentage_long_stay,
  minMediumStayRange,
  maxMediumStayRange,
  minLongStayRange,
  maxLongStayRange,
  bookings: initialBookings,
  maxGuests,
  disableDates,
  defaultCheckIn,
  defaultCheckOut,
  defaultGuests,
  onSubmit,
}: BookingWidgetProps) {
  const searchParams = useSearchParams()

  const [checkIn, setCheckIn] = useState<Date | undefined>(() => {
    if (defaultCheckIn) return parseISO(defaultCheckIn)
    const checkInParam = searchParams.get("checkIn")
    return checkInParam ? parseISO(checkInParam) : undefined
  })
  const [checkOut, setCheckOut] = useState<Date | undefined>(() => {
    if (defaultCheckOut) return parseISO(defaultCheckOut)
    const checkOutParam = searchParams.get("checkOut")
    return checkOutParam ? parseISO(checkOutParam) : undefined
  })
  const [guests, setGuests] = useState(() => {
    if (defaultGuests) return Math.min(defaultGuests, maxGuests)
    const travelersParam = searchParams.get("travelers")
    return travelersParam ? Math.min(Number.parseInt(travelersParam, 10), maxGuests) : 1
  })
  const [nights, setNights] = useState(0)
  const [totalPrice, setTotalPrice] = useState(0)

  const bookings = initialBookings

  const today = useMemo(() => {
    const todayDate = new Date()
    todayDate.setHours(0, 0, 0, 0)
    return todayDate
  }, [])

  useEffect(() => {
    if (checkIn && checkOut) {
      const nightsCount = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 3600 * 24))
      setNights(nightsCount)
    } else {
      setNights(0)
    }
  }, [checkIn, checkOut])

  useEffect(() => {
    const subtotal = price * nights * guests
    let discount = 0

    if (nights >= minLongStayRange && nights <= maxLongStayRange) {
      discount = subtotal * (discount_percentage_long_stay / 100)
    } else if (nights >= minMediumStayRange && nights <= maxMediumStayRange) {
      discount = subtotal * (discount_percentage_medium_stay / 100)
    }

    const discountedSubtotal = subtotal - discount
    const cleaningFee = cleaning
    setTotalPrice(discountedSubtotal + cleaningFee)
  }, [
    price,
    nights,
    guests,
    cleaning,
    discount_percentage_medium_stay,
    discount_percentage_long_stay,
    minMediumStayRange,
    maxMediumStayRange,
    minLongStayRange,
    maxLongStayRange,
  ])

  const getDiscountStayType = useMemo(() => {
    if (nights < minMediumStayRange) {
      return "short"
    } else if (nights >= minLongStayRange && nights <= maxLongStayRange) {
      return "long"
    } else if (nights >= minMediumStayRange && nights <= maxMediumStayRange) {
      return "medium"
    }
    return "short"
  }, [nights, minMediumStayRange, maxMediumStayRange, minLongStayRange, maxLongStayRange])

  const calculateDiscount = useMemo(() => {
    if (nights >= minLongStayRange && nights <= maxLongStayRange) {
      return discount_percentage_long_stay
    } else if (nights >= minMediumStayRange && nights <= maxMediumStayRange) {
      return discount_percentage_medium_stay
    }
    return 0
  }, [
    nights,
    minMediumStayRange,
    maxMediumStayRange,
    minLongStayRange,
    maxLongStayRange,
    discount_percentage_medium_stay,
    discount_percentage_long_stay,
  ])

  const handleGuestsChange = (increment: number) => {
    setGuests((prevGuests) => Math.max(1, Math.min(prevGuests + increment, maxGuests)))
  }

  const isDateReserved = useMemo(() => {
    const reservedDates: string[] = []

    bookings.forEach((booking) => {
      let currentDate = parseISO(booking.checkIn)
      const endDate = parseISO(booking.checkOut)

      while (currentDate <= endDate) {
        reservedDates.push(format(currentDate, "yyyy-MM-dd"))
        currentDate = addDays(currentDate, 1)
      }
    })

    if (disableDates) {
      JSON.parse(disableDates).forEach((disabledDate: string) => {
        reservedDates.push(disabledDate)
      })
    }

    return (date: Date) => {
      const formattedDate = format(date, "yyyy-MM-dd")
      return reservedDates.includes(formattedDate)
    }
  }, [bookings, disableDates])

  const handleCheckInSelect = (date: Date | undefined) => {
    if (date) {
      const nextAvailableDate = findNextAvailableDate(date)
      setCheckIn(nextAvailableDate)
      if (checkOut && nextAvailableDate >= checkOut) {
        setCheckOut(undefined)
      }
    } else {
      setCheckIn(undefined)
    }
  }

  const findNextAvailableDate = (startDate: Date): Date => {
    let currentDate = startDate
    while (isDateReserved(currentDate)) {
      currentDate = addDays(currentDate, 1)
    }
    return currentDate
  }

  const hasReservedDateBetween = (start: Date, end: Date): boolean => {
    let currentDate = addDays(start, 1)
    while (currentDate < end) {
      if (isDateReserved(currentDate)) {
        return true
      }
      currentDate = addDays(currentDate, 1)
    }
    return false
  }

  const isReservationEnabled = checkIn && checkOut && nights > 0

  const handleSubmit = () => {
    if (!onSubmit || !checkIn || !checkOut) return

    const subtotal = price * nights * guests
    const discountAmount = subtotal * (calculateDiscount / 100)

    const formattedBooking: BookingData = {
      checkIn: checkIn.toISOString().split("T")[0],
      checkOut: checkOut.toISOString().split("T")[0],
      guests: guests,
      nights: nights,
      price: price,
      cleaning: cleaning,
      discountStayType: getDiscountStayType,
      discountPercentageStayApplied: calculateDiscount,
      discountStayAmount: discountAmount,
      totalPrice: totalPrice,
    }

    onSubmit(formattedBooking)
  }

  const subtotal = price * nights * guests
  const discountAmount = subtotal * (calculateDiscount / 100)
  const discountStayType = getDiscountStayType
  const discountPercentageStayApplied = calculateDiscount

  return (
    <div className="border rounded-lg p-6 space-y-6 shadow-md bg-white">
      <div className="flex justify-between items-center">
        <div>
          <span className="text-3xl font-bold text-[#39759E]">${price.toLocaleString("es-CO")} USD</span>
          <span className="text-[#162F40] ml-2">/noche</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Popover>
          <PopoverTrigger asChild>
            <div className="relative">
              <Button
                variant="outline"
                className={`w-full justify-start text-left font-normal ${!checkIn && "text-muted-foreground"}`}
              >
                <CalendarIcon className="mr-0 h-4 w-4" />
                {checkIn ? format(checkIn, "PP", { locale: es }) : "Llegada"}
              </Button>
              {checkIn && (
                <X
                  className="absolute right-1 top-3 h-4 w-4 cursor-pointer text-gray-500 hover:text-red-500"
                  onClick={() => setCheckIn(undefined)}
                />
              )}
            </div>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={checkIn}
              onSelect={handleCheckInSelect}
              disabled={(date) => {
                const isBeforeToday = date < today
                return isBeforeToday || isDateReserved(date)
              }}
              defaultMonth={checkIn || today}
              modifiers={{
                reserved: isDateReserved,
              }}
              modifiersClassNames={{
                reserved: styles.reservedDate,
              }}
            />
          </PopoverContent>
        </Popover>
        <Popover>
          <PopoverTrigger asChild>
            <div className="relative">
              <Button
                variant="outline"
                className={`w-full justify-start text-left font-normal ${!checkOut && "text-muted-foreground"}`}
              >
                <CalendarIcon className="mr-0 h-4 w-4" />
                {checkOut ? format(checkOut, "PP", { locale: es }) : "Salida"}
              </Button>
              {checkIn && (
                <X
                  className="absolute right-1 top-3 h-4 w-4 cursor-pointer text-gray-500 hover:text-red-500"
                  onClick={() => setCheckOut(undefined)}
                />
              )}
            </div>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={checkOut}
              onSelect={setCheckOut}
              disabled={(date) => {
                const isBeforeOrEqualCheckIn = date <= (checkIn || today)
                const hasBetweenReservation = checkIn ? hasReservedDateBetween(checkIn, date) : false
                return isBeforeOrEqualCheckIn || isDateReserved(date) || hasBetweenReservation
              }}
              defaultMonth={checkOut || checkIn || today}
              modifiers={{
                reserved: isDateReserved,
              }}
              modifiersClassNames={{
                reserved: styles.reservedDate,
              }}
            />
          </PopoverContent>
        </Popover>
      </div>

      {nights > 0 && (
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <p className="text-sm text-blue-800 font-medium">
              {discountStayType === "long" ? (
                <>
                  Elegiste <span className="font-bold">{nights} noches</span> que equivale a una
                  <span className="font-bold text-blue-900"> estadía larga </span>
                  con un descuento del{" "}
                  <span className="font-bold text-green-600">{discountPercentageStayApplied}%</span>
                </>
              ) : discountStayType === "medium" ? (
                <>
                  Elegiste <span className="font-bold">{nights} noches</span> que equivale a una
                  <span className="font-bold text-blue-900"> estadía media </span>
                  con un descuento del{" "}
                  <span className="font-bold text-green-600">{discountPercentageStayApplied}%</span>
                </>
              ) : (
                <>
                  {nights < minMediumStayRange && (
                    <span className="text-blue-700">
                      ¡Considera quedarte {minMediumStayRange} noches o más para obtener descuentos especiales!
                    </span>
                  )}
                </>
              )}
            </p>
          </div>
        </div>
      )}

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <Label className="flex items-center gap-2 text-[#162F40]">
            <Users className="h-5 w-5" />
            Huéspedes
          </Label>
          <div className="flex items-center border rounded-md">
            <Button type="button" variant="ghost" className="p-2" onClick={() => handleGuestsChange(-1)}>
              <Minus className="h-4 w-4" />
            </Button>
            <Input value={guests} readOnly className="w-12 text-center border-none" />
            <Button
              type="button"
              variant="ghost"
              className="p-2"
              onClick={() => handleGuestsChange(1)}
              disabled={guests >= maxGuests}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
        {nights > 0 && (
          <div className="space-y-2 bg-gray-50 p-4 rounded-md">
            <div className="flex justify-between items-center text-sm">
              <span className="text-[#162F40]">
                ${price.toLocaleString("es-CO")} x {nights} noche(s) x {guests}
              </span>
              <span className="font-semibold">
                ${(price * nights * guests).toLocaleString("es-CO")}{" "}
                <span className="font-semibold text-[#162F40]">USD</span>
              </span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between items-center text-sm">
                <span className="text-green-600">
                  {discountStayType === "long"
                    ? `Estadía larga (-${discountPercentageStayApplied}%)`
                    : `Estadía media (-${discountPercentageStayApplied}%)`}
                </span>
                <span className="font-semibold text-green-600">-${discountAmount.toLocaleString("es-CO")} USD</span>
              </div>
            )}
            <div className="flex justify-between items-center text-sm">
              <span className="text-[#162F40]">Tarifa de limpieza</span>
              <span className="font-semibold">${cleaning.toLocaleString("es-CO")} USD</span>
            </div>
            <div className="flex justify-between items-center text-sm pt-2 border-t">
              <span className="text-[#162F40] font-semibold">Total</span>
              <span className="font-bold text-lg">${totalPrice.toLocaleString("es-CO")} USD</span>
            </div>
          </div>
        )}
      </div>

      <Button
        className="w-full bg-[#39759E] hover:bg-[#2c5a7a] text-white font-semibold py-3 rounded-md transition-colors duration-300"
        disabled={!isReservationEnabled}
        onClick={handleSubmit}
      >
        Modificar reserva
      </Button>
    </div>
  )
}
