"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { getPropertiesByUserId, type Property } from "@/services/propertyCollectionService"
import { getCurrentUser, type User } from "@/services/userService"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Plus, Loader2, BedDouble, Building2, CheckCircle, AlertCircle } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Fraunces } from "next/font/google"

const fraunces = Fraunces({ subsets: ["latin"] })

const PropertiesPage: React.FC = () => {
  const router = useRouter()
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)
 

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const token = localStorage.getItem("access_token")
        if (!token) {
          throw new Error("Token no encontrado. Inicia sesión nuevamente.")
        }

        const currentUser: User = await getCurrentUser(token)
        const data = await getPropertiesByUserId(currentUser.id, token)

        setProperties(data)
        localStorage.setItem("properties", JSON.stringify(data))
      } catch (err: unknown) {
        if (err instanceof Error) {
          setError(err.message)
        } else {
          setError("Error inesperado")
        }
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2 text-lg text-gray-700">Cargando propiedades...</span>
      </div>
    )
  }

  if (error) {
    return <p className="text-center p-4 text-red-500">Error: {error}</p>
  }

  const decodeHtmlAndRemoveTags = (html: string): string => {
    const textWithoutTags = html.replace(/<\/?[^>]+(>|$)/g, "")
    const txt = document.createElement("textarea")
    txt.innerHTML = textWithoutTags
    return txt.value
  }

  return (
    <div className="container min-h-screen mx-auto py-4">
      
      {properties.length === 0 ? (
       
          <div className="container min-h-screen mx-auto p-4 py-4">
            <div className="max-w-xl mx-auto">
              <div className="flex flex-col items-center justify-center text-center space-y-8 py-16">
                <div className="w-20 h-20 rounded-full bg-[#39759E]/10 flex items-center justify-center">
                  <Building2 className="w-10 h-10 text-[#39759E]" />
                </div>
    
                <div className="space-y-3">
                <h1
            className={`${fraunces.className} text-3xl font-normal text-[#162F40] mb-8`}
          >
             Aún no has registrado una propiedad
          </h1>
                  <p className="text-base text-gray-600 max-w-md mx-auto">
                  Dar el primer paso para convertirte en anfitrión puede ser el comienzo de una experiencia increíble.                  </p>
                </div>
    
                <Button
                  size="lg"
                  className="mt-4 px-8 hover:opacity-90 transition-opacity"
                  style={{ backgroundColor: "#39759E" }}
                  onClick={() => router.push("/mi-panel/registrar-propiedad")}
                >
                 <Plus className="mr-2 h-5 w-5" /> Agregar Propiedad
                </Button>
              </div>
            </div>
          </div>
        
      ) : (
        <div>
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-8">
        <h1 className={`${fraunces.className} text-3xl font-normal text-[#162F40] mb-4`}>
                    Mis Propiedades
              </h1>
        <Link href="/mi-panel/registrar-propiedad" className="w-full sm:w-auto">
          <Button className="w-full sm:w-auto bg-[#39759E] text-white hover:bg-[#2c5a7a] transition-colors duration-300">
            <Plus className="mr-2 h-5 w-5" /> Nueva Propiedad
          </Button>
        </Link>
      </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
          {properties.map((property) => (
            <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <div className="flex flex-col sm:flex-row">
                <div className="relative w-full sm:w-2/5 h-48 sm:h-auto">
                  <Link href={`/mi-panel/propiedades/${property.id}`}>
                    <Image
                      src={`/webapi/assets/${property.mainImage || "/placeholder.svg"}?key=medium`}
                      alt={property.name}
                      layout="fill"
                      objectFit="cover"
                      className="transition-transform duration-300 hover:scale-105"
                    />
                  </Link>
                </div>
                <CardContent className="flex-1 p-4 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                    <h2 className={`${fraunces.className} text-2xl font-normal text-[#162F40] mb-4`}>
                    {property.name}
              </h2>
                 
                    </div>
                    <p className="text-sm text-gray-500 mb-2 flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {property.country}
                    </p>
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {decodeHtmlAndRemoveTags(property.description) || "Sin descripción"}
                    </p>
                    <p className="text-sm text-gray-500 mt-2 flex items-center">
                      <BedDouble className="h-4 w-4 mr-1" />
                      {property.Rooms?.length || 0} habitación{property.Rooms?.length !== 1 ? "es" : ""}
                    </p>
                  </div>
                  <div className="mt-4 flex justify-between items-center">
                    <div className="space-x-2">
                      <Link href={`/mi-panel/propiedades/${property.id}`}>
                        <Button variant="outline" size="sm">
                          Ver detalles
                        </Button>
                      </Link>
                    </div>
                    {property.taxIdApproved ? (
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Aprobado
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-300">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        En Revisión
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
        </div>
      )}
    </div>
  )
}

export default PropertiesPage
